README for dataset1 – Interval Transportation Problem Instance

Instance Overview
-----------------
This file describes a single instance of an interval transportation problem, where
both supply capacities at origins and demand level at destinations are defined through intervals rather than fixed values.

Instance Naming Convention
--------------------------
The instance filename follows this structure:

id_<ID>_s_<s>_O_<O>_D_<D>_G_<G>_V_<V>_cMin_<cMin>_cMax_<cMax>.txt

where:
- ID    : unique identifier of the instance
- s     : random seed used for instance generation
- O     : number of origins
- D     : number of destinations
- G     : base width of the capacity and demand intervals
- V     : maximum variability applied to the interval gap
- cMin  : minimum cost value in the cost matrix
- cMax  : maximum cost value in the cost matrix

File Structure
--------------
The file is organized as follows.

1. Origin Capacity Intervals
   Line 1: lower bounds of the supply capacities for the O origins.
           Format: [l_1, l_2, ..., l_O]

   Line 2: upper bounds of the supply capacities for the O origins.
           Format: [u_1, u_2, ..., u_O]

   Each origin i has a supply capacity interval [l_i, u_i].

2. Destination Demand Intervals
   Line 3: lower bounds of the demand levels for the D destinations.
           Format: [l_1, l_2, ..., l_D]

   Line 4: upper bounds of the demand levels for the D destinations.
           Format: [u_1, u_2, ..., u_D]

   Each destination j has a demand interval [l_j, u_j].

3. Cost Matrix
   The remainder of the file contains the O x D cost matrix, representing the unit transportation cost from each origin to each destination.

   - The matrix is enclosed in two outer square brackets
   - Each row corresponds to an origin
   - Each row is enclosed in square brackets
   - Cost values are separated by commas
   - Rows are separated by commas

   Format:
   [
     [c_11, c_12, ..., c_1D],
     [c_21, c_22, ..., c_2D],
     ...
     [c_O1, c_O2, ..., c_OD]
   ]

Summary
-------
This instance represents an interval-based transportation problem characterized by interval supply capacities at origins, interval demand level at destinations, and a complete origin–destination cost matrix.
